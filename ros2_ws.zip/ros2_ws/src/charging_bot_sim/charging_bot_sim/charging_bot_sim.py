#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import math
import time

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from visualization_msgs.msg import MarkerArray

import numpy as np


class ChargingBot(Node):

    def __init__(self):
        super().__init__("charging_bot_simulation")

        # -----------------------------------------
        # PARAMETERS (tweak here)
        # -----------------------------------------
        self.R = 4.0                 # charging radius (m)
        self.V_MAX = 2.0             # max linear speed (m/s)
        self.W_MAX = 1.5             # max angular speed (rad/s) - reduced for stability
        self.GOAL_TOL = 0.20         # arrival tolerance (m)
        self.dwell_time = 4.0        # seconds to "charge" at a stop

        # Controller gains
        self.K_angular = 1.0         # proportional gain for angular velocity
        self.K_linear = 0.6          # proportional gain for linear from distance

        # Safety thresholds
        self.ANGLE_DEADZONE = 0.08   # radians (≈4.5°) — no small ang commands to avoid jitter
        self.MAX_STEP_DIST = 1.0     # m, ignore odom jumps larger than this per update
        self.MIN_COUNT_STEP = 1e-4   # m, ignore extremely tiny steps as noise

        # Shutdown flag
        self.active = True

        # -----------------------------------------
        # LOAD ground_nodes & waypoints (semicolon-separated "x,y;..." files)
        # -----------------------------------------
        try:
            self.waypoints = self.load_xy_file("/tmp/optimal_path.txt")
        except Exception as e:
            self.get_logger().error(f"Failed to load /tmp/optimal_path.txt: {e}")
            self.waypoints = []

        try:
            self.nodes = self.load_xy_file("/tmp/ground_nodes.txt")
        except Exception as e:
            self.get_logger().error(f"Failed to load /tmp/ground_nodes.txt: {e}")
            self.nodes = []

        self.get_logger().info("Loaded waypoints:")
        for i, p in enumerate(self.waypoints):
            self.get_logger().info(f"  Stop {i+1}: ({p[0]:.3f}, {p[1]:.3f})")
        self.get_logger().info("Loaded nodes:")
        for i, p in enumerate(self.nodes):
            self.get_logger().info(f"  Node {i}: ({p[0]:.3f}, {p[1]:.3f})")

        self.total_nodes = len(self.nodes)
        self.charged = [False] * self.total_nodes

        # -----------------------------------------
        # PUBLISHERS / SUBSCRIBERS
        # -----------------------------------------
        self.cmd_pub = self.create_publisher(Twist, "/cmd_vel", 10)
        self.marker_pub = self.create_publisher(MarkerArray, "/visualization_markers", 10)
        self.odom_sub = self.create_subscription(Odometry, "/odom", self.cb_odom, 10)

        # Timer (50 ms)
        self.timer = self.create_timer(0.05, self.timer_cb)

        # -----------------------------------------
        # STATE VARIABLES
        # -----------------------------------------
        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0
        self.odom_received = False

        # Distance tracking
        self.prev_x = None
        self.prev_y = None
        self.total_dist = 0.0
        self.is_moving = False

        self.current_target = 0
        self.start_time = None          # set when first odometry arrives
        self.dwelling = False
        self.dwell_start_time = None

        # Theoretical path distance/time (computed even if waypoints empty -> 0)
        self.theoretical_dist = self.compute_theoretical_distance()
        # If V_MAX is 0, avoid division by zero
        travel_time = (self.theoretical_dist / self.V_MAX) if self.V_MAX > 1e-6 else 0.0
        self.theoretical_time = travel_time + len(self.waypoints) * self.dwell_time

        self.get_logger().info("=" * 60)
        self.get_logger().info("🤖 GA-Optimized Charging Bot Node Ready")
        self.get_logger().info(f"📍 Waypoints: {len(self.waypoints)}")
        self.get_logger().info(f"🔵 Ground Nodes: {len(self.nodes)}")
        self.get_logger().info(f"⚡ Charging Range: {self.R} m")
        self.get_logger().info(f"🏃 V_MAX: {self.V_MAX} m/s")
        self.get_logger().info(f"🌀 W_MAX: {self.W_MAX} rad/s")
        self.get_logger().info(f"GOAL_TOL: {self.GOAL_TOL} m")
        self.get_logger().info(f"⏱ Theoretical Mission Time: {self.theoretical_time:.3f} s")
        self.get_logger().info("=" * 60)

    # ==========================================================
    # LOAD a semicolon separated "x,y;..." file
    # ==========================================================
    def load_xy_file(self, path):
        with open(path, "r") as f:
            txt = f.read().strip()
        pts = []
        if not txt:
            return pts
        for p in txt.split(";"):
            p = p.strip()
            if not p:
                continue
            parts = p.split(",")
            if len(parts) < 2:
                continue
            x = float(parts[0])
            y = float(parts[1])
            pts.append([x, y])
        return pts

    # ==========================================================
    # COMPUTE THEORETICAL PATH LENGTH (start at 0,0)
    # ==========================================================
    def compute_theoretical_distance(self):
        dist = 0.0
        cx, cy = 0.0, 0.0
        for (x, y) in self.waypoints:
            dist += math.hypot(x - cx, y - cy)
            cx, cy = x, y
        return dist

    # ==========================================================
    # ODOM CALLBACK
    # ==========================================================
    def cb_odom(self, msg):
        # Update position and orientation; update total_dist with robust checks
        new_x = float(msg.pose.pose.position.x)
        new_y = float(msg.pose.pose.position.y)

        # set start_time on first odom
        if not self.odom_received:
            self.start_time = self.get_clock().now()
            self.prev_x = new_x
            self.prev_y = new_y
            self.odom_received = True
        else:
            # compute step distance
            dx = new_x - self.prev_x
            dy = new_y - self.prev_y
            step_dist = math.hypot(dx, dy)

            # accept reasonable step distances only to avoid odom jumps
            if self.is_moving and (self.MIN_COUNT_STEP < step_dist < self.MAX_STEP_DIST):
                self.total_dist += step_dist

            # update prev
            self.prev_x = new_x
            self.prev_y = new_y

        # update pose
        self.x = new_x
        self.y = new_y

        # Quaternion -> yaw
        q = msg.pose.pose.orientation
        siny = 2.0 * (q.w * q.z + q.x * q.y)
        cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        self.yaw = math.atan2(siny, cosy)

    # ==========================================================
    # MAIN CONTROL LOOP (timer_cb)
    # ==========================================================
    def timer_cb(self):
        # don't run until we have odometry and node is active
        if not self.active or not self.odom_received:
            return

        # mission complete?
        if self.current_target >= len(self.waypoints):
            # finalize once
            if not self.dwelling:  # ensure not mid-dwell
                self.finish_mission()
            return

        # handle dwelling (non-blocking)
        if self.dwelling:
            elapsed = (self.get_clock().now() - self.dwell_start_time).nanoseconds / 1e9
            # still dwelling
            if elapsed < self.dwell_time:
                # ensure robot stopped during dwell
                self.stop_robot()
                self.is_moving = False
                return
            # finished dwell -> move to next target
            self.dwelling = False
            self.current_target += 1
            # small pause to let odom settle
            return

        # current goal
        gx, gy = self.waypoints[self.current_target]
        dx = gx - self.x
        dy = gy - self.y
        distance = math.hypot(dx, dy)

        # reached?
        if distance < self.GOAL_TOL:
            # arrived at waypoint: stop, charge, start dwell
            self.stop_robot()
            self.charge_here()
            return

        # heading
        desired_angle = math.atan2(dy, dx)
        angle_error = desired_angle - self.yaw
        # normalize to [-pi, pi]
        angle_error = math.atan2(math.sin(angle_error), math.cos(angle_error))

        # build command
        cmd = Twist()

        # If angle is large, rotate in place to avoid forward drift
        if abs(angle_error) > 1.0:
            # rotate in place with moderate angular velocity (sign preserved)
            cmd.linear.x = 0.0
            cmd.angular.z = max(min(self.W_MAX * math.copysign(0.9, angle_error), self.W_MAX), -self.W_MAX)
            self.is_moving = False
        else:
            # angular P-control (with deadzone to avoid jitter)
            ang = self.K_angular * angle_error
            if abs(ang) < self.ANGLE_DEADZONE:
                ang = 0.0
            cmd.angular.z = max(min(ang, self.W_MAX), -self.W_MAX)

            # linear P-control scaled by heading error
            if abs(angle_error) < 0.7:
                lin = self.K_linear * distance
                # reduce speed if angle error non-zero
                lin *= max(0.0, (1.0 - abs(angle_error) / math.pi))
                cmd.linear.x = max(0.0, min(lin, self.V_MAX))
                self.is_moving = cmd.linear.x > 1e-3
            else:
                cmd.linear.x = 0.0
                self.is_moving = False

        # Publish safely (suppress exceptions from rmw if any leftover)
        try:
            self.cmd_pub.publish(cmd)
        except Exception:
            # don't spam logs; in some race cases rmw may reject publishes when shutting down
            pass

    # ==========================================================
    # CHARGING ROUTINE (non-blocking dwell)
    # ==========================================================
    def charge_here(self):
        gx, gy = self.waypoints[self.current_target]
        newly = []
        for i, (nx, ny) in enumerate(self.nodes):
            if not self.charged[i] and math.hypot(nx - gx, ny - gy) <= self.R:
                self.charged[i] = True
                newly.append(i)

        self.get_logger().info(f"✓ Reached Stop {self.current_target+1} (pos: {gx:.3f},{gy:.3f})")
        if newly:
            self.get_logger().info(f"  ⚡ Charging Nodes {newly}")
        else:
            self.get_logger().info("  ℹ️ No new nodes in range")

        # start non-blocking dwell
        self.dwelling = True
        self.dwell_start_time = self.get_clock().now()

    # ==========================================================
    # STOP ROBOT (publish 0 velocities)
    # ==========================================================
    def stop_robot(self):
        self.is_moving = False
        cmd = Twist()
        try:
            self.cmd_pub.publish(cmd)
        except Exception:
            pass

    # ==========================================================
    # FINISH MISSION (no rclpy.shutdown here)
    # ==========================================================
    def finish_mission(self):
        if not self.active:
            return
        self.active = False

        # cancel timer to stop calling timer_cb
        try:
            self.timer.cancel()
        except Exception:
            pass

        # ensure robot stopped
        self.stop_robot()

        charged = sum(self.charged)
        real_time = 0.0
        if self.start_time is not None:
            real_time = (self.get_clock().now() - self.start_time).nanoseconds / 1e9

        self.get_logger().info("\n" + "=" * 60)
        self.get_logger().info("🎉 MISSION COMPLETE!")
        self.get_logger().info(f"✓ Stops visited: {len(self.waypoints)}")
        self.get_logger().info(f"⚡ Nodes charged: {charged}/{self.total_nodes} ({100*charged/self.total_nodes:.1f}%)")
        self.get_logger().info(f"📏 Theoretical path distance: {self.theoretical_dist:.3f} m")
        self.get_logger().info(f"📏 Actual odom distance:      {self.total_dist:.3f} m")
        self.get_logger().info(f"⏱ Theoretical time:          {self.theoretical_time:.3f} s")
        self.get_logger().info(f"⏱ Real wall time:            {real_time:.3f} s")
        self.get_logger().info("=" * 60)

        # Do NOT call rclpy.shutdown() here (caller will handle it)

# ================================================================
# MAIN()
# ================================================================
def main(args=None):
    rclpy.init(args=args)
    node = ChargingBot()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # ensure finish printed
        if node.active:
            node.finish_mission()
        # destroy node and shutdown once
        try:
            node.destroy_node()
        except Exception:
            pass
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()

