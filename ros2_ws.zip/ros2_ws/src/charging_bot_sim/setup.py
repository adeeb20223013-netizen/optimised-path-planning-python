from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'charging_bot_sim'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'worlds'), glob('worlds/*.sdf')),
        (os.path.join('share', package_name, 'models/charging_bot'), 
            glob('models/charging_bot/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='User',
    maintainer_email='user@example.com',
    description='Mobile charging bot Gazebo simulation',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'charging_bot_sim = charging_bot_sim.charging_bot_sim:main',
        ],
    },
)
