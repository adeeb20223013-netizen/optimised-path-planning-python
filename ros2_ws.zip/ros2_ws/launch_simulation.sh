#!/bin/bash

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}Starting Charging Bot Simulation...${NC}\n"

source ~/ros2_ws/install/setup.bash
export GZ_SIM_RESOURCE_PATH=$GZ_SIM_RESOURCE_PATH:~/ros2_ws/install/charging_bot_sim/share/charging_bot_sim/models

WORLD_FILE=~/ros2_ws/install/charging_bot_sim/share/charging_bot_sim/worlds/charging_world.sdf
ROBOT_FILE=~/ros2_ws/install/charging_bot_sim/share/charging_bot_sim/models/charging_bot/charging_bot.sdf

echo -e "${YELLOW}[1/5]${NC} Launching Gazebo..."
gz sim "$WORLD_FILE" -r &
GZ_PID=$!
sleep 8

echo -e "${YELLOW}[2/5]${NC} Spawning robot..."
gz service -s /world/charging_bot_world/create \
  --reqtype gz.msgs.EntityFactory \
  --reptype gz.msgs.Boolean \
  --timeout 1000 \
  --req "sdf_filename: \"$ROBOT_FILE\", name: \"charging_bot\", pose: {position: {x: 0, y: 0, z: 0.3}}" &
sleep 3

echo -e "${YELLOW}[3/5]${NC} Starting ROS-Gazebo bridge..."
ros2 run ros_gz_bridge parameter_bridge \
  /cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist \
  /odom@nav_msgs/msg/Odometry@gz.msgs.Odometry \
  /clock@rosgraph_msgs/msg/Clock@gz.msgs.Clock &
BRIDGE_PID=$!
sleep 2

echo -e "${YELLOW}[4/5]${NC} Starting RViz..."
ros2 run rviz2 rviz2 &
RVIZ_PID=$!
sleep 2

echo -e "${GREEN}╔════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  Setup Complete!                      ║${NC}"
echo -e "${GREEN}║                                        ║${NC}"
echo -e "${GREEN}║  RViz Instructions:                   ║${NC}"
echo -e "${GREEN}║  1. Set Fixed Frame to: map           ║${NC}"
echo -e "${GREEN}║  2. Add → MarkerArray                 ║${NC}"
echo -e "${GREEN}║  3. Topic: /visualization_markers     ║${NC}"
echo -e "${GREEN}║                                        ║${NC}"
echo -e "${GREEN}║  Press Ctrl+C to stop all             ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════╝${NC}\n"

cleanup() {
    echo -e "\n${YELLOW}Shutting down...${NC}"
    kill $GZ_PID $BRIDGE_PID $RVIZ_PID 2>/dev/null
    echo -e "${GREEN}✓ Cleanup complete${NC}"
    exit 0
}

trap cleanup INT TERM

echo -e "${YELLOW}[5/5]${NC} Starting simulation node..."
ros2 run charging_bot_sim charging_bot_sim

cleanup
