#!/bin/bash

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}Checking Simulation Status...${NC}\n"

check() {
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓${NC} $1"
    else
        echo -e "${RED}✗${NC} $1"
    fi
}

echo "ROS 2 Environment:"
source ~/ros2_ws/install/setup.bash
ros2 pkg list | grep -q charging_bot_sim
check "Package installed"

echo -e "\nData Files:"
[ -f /tmp/optimal_path.txt ] && echo -e "${GREEN}✓${NC} Waypoints file" || echo -e "${RED}✗${NC} Waypoints file"
[ -f /tmp/ground_nodes.txt ] && echo -e "${GREEN}✓${NC} Ground nodes file" || echo -e "${RED}✗${NC} Ground nodes file"

echo -e "\nRunning Processes:"
pgrep -f "gz sim" > /dev/null && echo -e "${YELLOW}!${NC} Gazebo running (PID: $(pgrep -f 'gz sim'))" || echo -e "${GREEN}✓${NC} No Gazebo"
pgrep -f "rviz2" > /dev/null && echo -e "${YELLOW}!${NC} RViz running" || echo -e "${GREEN}✓${NC} No RViz"

echo -e "\nTo start simulation:"
echo -e "${BLUE}./launch_simulation.sh${NC}"
